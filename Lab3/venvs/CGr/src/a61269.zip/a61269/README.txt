Os imports são feitos através do diretório Core presente neste ZIP.

O ficheiro requirements.txt necessário também se encontra presente e o usado foi o ficheiro fornecido pela professora através do repositório.