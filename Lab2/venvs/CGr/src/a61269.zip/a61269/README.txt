O ficheiro requirements é o ficheiro presente no diretório "E1" do repositório da professora.

Tendo usado o diretório "src3" como referencia, os importes são os ficheiros presentes no diretório "core".