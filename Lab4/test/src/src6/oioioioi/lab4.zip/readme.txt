Utilizei o blender.

O ficheiro requirements.txt é o ficheiro presente em E1,
no GitHub da professora.

Na pasta core, encontra-se o meu ficheiro .obj, juntamente 
com o ficheiro que obj_loader que a professora mostrou no pdf:
LAB4_help.

Entreguei tarde pois pensava que a professora queria que
os materials do objecto também dessem render.