O ficheiro requirements é o ficheiro presente no GitHub da professora.

Todos os ficheiros necessários para a execução deste lab encontram-se dentro deste zip.
Basta correr o ficheiro lab5.py.